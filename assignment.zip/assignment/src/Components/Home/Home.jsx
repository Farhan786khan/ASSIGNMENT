import { useEffect, useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import homemain from "../../assets/images/homemain.png";
import homeone from "../../assets/images/homeone.png";
import hometwo from "../../assets/images/hometwo.png";
import homethree from "../../assets/images/homethree.png";
import homefour from "../../assets/images/homefour.png";
import style from "./Home.module.css";

const Home = () => {
  const [showH1, setShowH1] = useState(true);

  useEffect(() => {
    // After 5 seconds, hide the h1 tag
    const timer = setTimeout(() => {
      setShowH1(false);
    }, 5000); // Adjust the delay here if needed, in milliseconds

    return () => clearTimeout(timer);
  }, []);
  return (
    <div className="container d-flex align-items-center justify-content-between">
      <div className="text-center">
        {showH1 && (
          <h1 className={`font-weight-bold ${style.slideMarquee}`}>
            Taking care for your pets!
          </h1>
        )}
        {!showH1 && (
          <h2 className={`font-weight-bold ${style.slideDown}`}>
            Get various services personalized for your pets like
          </h2>
        )}
      </div>
      <div className="d-flex flex-column align-items-center position-relative mt-5">
        <img
          src={homemain}
          alt="Pet"
          className="img-fluid"
          style={{ zIndex: 5, width: "396px", height: "546px" }}
        />
        <img
          src={homeone}
          alt="Pet"
          className={`${style.imageOne} img-fluid position-absolute`}
          style={{}}
        />
        <img
          src={hometwo}
          alt="Pet"
          className={`${style.imageSecond} img-fluid position-absolute`}
        />
        <img
          src={homethree}
          alt="Pet"
          className={`${style.imageThird} img-fluid position-absolute`}
        />
        <img
          src={homefour}
          alt="Pet"
          className={`${style.imageFour} img-fluid position-absolute`}
        />
      </div>
    </div>
  );
};

export default Home;
