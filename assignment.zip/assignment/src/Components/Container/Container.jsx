/* eslint-disable react/prop-types */
import bgImage from "../../assets/images/bgvector.png";
import DogFootSVG from "../DogFootSVG";

const FixedFootStep = ({ size, position, color }) => {
  return (
    <div
      style={{
        position: "fixed",
        ...position,
        zIndex: -1,
      }}
    >
      <DogFootSVG color={color} height={size} width={size} className="me-1" />
    </div>
  );
};

function Container({ children }) {
  return (
    <div
      style={{
        backgroundImage: `url(${bgImage})`, // Set the background image
        backgroundSize: "cover", // Adjust background size as needed
        backgroundPosition: "center", // Adjust background position as needed
        minHeight: "100vh", // Example: minimum height of the container
        padding: "20px", // Example: padding around the content
      }}
    >
      {children}
      <FixedFootStep
        size={50}
        position={{
          bottom: "10%",
          left: "10%",
        }}
      />
      <FixedFootStep
        color="#FFAA00"
        size={70}
        position={{
          bottom: "3%",
          left: "50%",
        }}
      />
      <FixedFootStep
        color="#D9A6FF"
        size={50}
        position={{
          bottom: "8%",
          right: "5%",
        }}
      />
      <FixedFootStep
        color="#FF6E9F"
        size={50}
        position={{
          bottom: "25%",
          right: "60%",
        }}
      />
    </div>
  );
}

export default Container;
