/* eslint-disable react/prop-types */
import style from "./Category.module.css";
import categoriesData from "../../store/category.json";
import { useEffect, useState } from "react";
import cat1 from "../../assets/images/cat1.png";
import cat2 from "../../assets/images/cat2.png";
import cat3 from "../../assets/images/cat3.png";
import cat4 from "../../assets/images/cat4.png";
import DogFootSVG from "../DogFootSVG";

const CategoryComponent = () => {
  // Define image imports
  const catImages = [cat1, cat2, cat3, cat4];

  // Create state for categories and active category
  const [categories, setCategories] = useState([]);
  const [activeCategory, setActiveCategory] = useState(null);

  // Load data into state when component mounts
  useEffect(() => {
    setCategories(categoriesData);

    // Set the first category as active when categoriesData is loaded
    if (categoriesData.length > 0) {
      setActiveCategory(categoriesData[0]);
    }
  }, []);

  // Function to set active category based on ID
  const setActiveCategoryById = (categoryId) => {
    const category = categories.find((cat) => cat.id === categoryId);
    if (category) {
      setActiveCategory(category);
    }
  };

  return (
    <div className="container mt-5">
      <h2 className="mb-4">Categories</h2>
      <div className="row">
        <div className="col-md-8">
          {activeCategory && (
            <>
              <h4>{activeCategory.title}</h4>
              <p className={`${style.categoryDescription}`}>
                {activeCategory.description}
              </p>
            </>
          )}
          <button className={`mb-3 ${style.getStartedButton}`}>
            Get Started
          </button>
          <div className="d-flex">
            {categories.map((category, index) => (
              <button
                key={index}
                onClick={() => setActiveCategoryById(category.id)}
                className={`me-1 ${style.categoriesButton} ${
                  activeCategory && activeCategory.id === category.id
                    ? style.active
                    : ""
                }`}
              >
                <DogFootSVG
                  color="#FFAA00"
                  height={20}
                  width={20}
                  className="me-1"
                />
                {category.title}
              </button>
            ))}
          </div>
        </div>
        <div className="col-md-4">
          {activeCategory && (
            <img
              src={catImages[activeCategory.id - 1]} // Assuming IDs start from 1
              alt={activeCategory.title}
              className="img-fluid rounded-circle"
            />
          )}
        </div>
      </div>
    </div>
  );
};

export default CategoryComponent;
