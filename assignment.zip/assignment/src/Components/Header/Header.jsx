/* eslint-disable react/prop-types */
import { useRef, useState, useEffect } from "react";
import style from "./Header.module.css";

import { Link, useLocation } from "react-router-dom";
import DogFootSVG from "../DogFootSVG";
const Header = () => {
  const toggleRef = useRef(null);
  const [isToggle, setToggle] = useState(false);
  const handleClick = () => {
    setToggle((prevValue) => !prevValue);
  };
  useEffect(() => {
    const refCurrent = toggleRef.current;
    if (refCurrent) {
      refCurrent.addEventListener("click", handleClick);
    }
    return () => {
      if (refCurrent) {
        refCurrent.removeEventListener("click", handleClick);
      }
    };
  }, []);

  return (
    <header className="bg-white shadow-sm">
      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container">
          <a className={`navbar-brand ${style.title}`} href="#">
            <DogFootSVG
              color="#FFAA00"
              height={30}
              width={30}
              className="me-1"
            />
            Glocal
          </a>
          <button
            className="navbar-toggler"
            type="button"
            ref={toggleRef}
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav"
            aria-controls="navbarNav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <span className="navbar-toggler-icon"></span>
          </button>
          <div
            className={`navbar-collapse ${style.navContainer} ${
              isToggle ? "" : style.navActive
            }`}
            id="navbarNav"
          >
            <ul className="navbar-nav m-auto mb-2 mb-lg-0">
              <NavItem link="/" text="Home" />
              <NavItem link="/category" text="Categories" />
              <NavItem link="#" text="About Us" />
              <NavItem link="#" text="Products" />
              <NavItem link="#" text="Pet Care" />
              <NavItem link="#" text="Contact" />
            </ul>
            <div className="d-flex">
              <button className={` me-2 ${style.signInButton}`} type="button">
                Sign In
              </button>
              <button className={`${style.registerButton}`} type="button">
                Register
              </button>
            </div>
          </div>
        </div>
      </nav>
    </header>
  );
};

const NavItem = ({ link, text }) => {
  const location = useLocation();
  const isActive = location.pathname === link;

  return (
    <li className="nav-item">
      <Link
        className={`nav-link ${isActive ? style.linkActive : ""} ${
          style.links
        }`}
        to={link}
      >
        {text}
      </Link>
    </li>
  );
};

export default Header;
